package com.example.feri_kusuma_wardhana_tugas_6_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
