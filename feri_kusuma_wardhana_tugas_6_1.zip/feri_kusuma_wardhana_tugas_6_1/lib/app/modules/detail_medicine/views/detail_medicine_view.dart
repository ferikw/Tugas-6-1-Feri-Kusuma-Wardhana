import 'package:flutter/material.dart';
import 'package:feri_kusuma_wardhana_tugas_6_1/app/data/medicine.dart';
import 'package:feri_kusuma_wardhana_tugas_6_1/app/data/notification.dart'
    as notif;

import 'package:get/get.dart';

import '../controllers/detail_medicine_controller.dart';

class DetailMedicineView extends GetView<DetailMedicineController> {
  const DetailMedicineView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Jadwal Obat'),
        centerTitle: true,
      ),
      body: ListView(
        children: [
          FutureBuilder<Medicine>(
            future: controller.getMedicineData(Get.arguments),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return ListTile(
                  title: Text(
                    snapshot.data!.name,
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    "${snapshot.data!.frequency.toString()} kali sehari",
                    style: const TextStyle(fontSize: 16),
                  ),
                );
              } else {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              }
            },
          ),
          FutureBuilder<List<notif.Notification>>(
            future: controller.getNotificationData(Get.arguments),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return ListView.builder(
                  shrinkWrap: true,
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      leading: const Icon(Icons.alarm),
                      title: Text(
                        snapshot.data![index].time,
                        style: const TextStyle(fontSize: 18),
                      ),
                    );
                  },
                );
              } else {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              }
            },
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24.0),
                ),
              ),
              onPressed: () {
                controller.deleteMedicine(Get.arguments);
              },
              icon: const Icon(Icons.cancel),
              label: const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  'Saya tidak butuh obat lagi',
                  style: TextStyle(fontSize: 18),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
